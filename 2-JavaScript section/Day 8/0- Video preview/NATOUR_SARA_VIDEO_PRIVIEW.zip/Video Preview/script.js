function playVid(elem){
    elem.play();
    elem.style.cursor = "pointer";
    // elem.mute();
}
function pauseVid(e){
    e.pause();

}
